<template>
  <div id="app">
    <BestTransport/>
  </div>
</template>

<script>
import BestTransport from './components/BestTransport.vue'

export default {
  name: 'App',
  components: {
    BestTransport
  }
}
</script>

<style>
</style>
