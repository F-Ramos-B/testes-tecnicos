package br.com.stefanini.dto;

/**
 * @author danilo
 * @version 0.1.0
 * @email maratona@stefanini.com
 * @created 23/09/2021 on 21:10
 */
public class NovaPessoaDto {
}
