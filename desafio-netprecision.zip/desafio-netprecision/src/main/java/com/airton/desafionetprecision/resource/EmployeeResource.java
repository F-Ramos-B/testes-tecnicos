package com.airton.desafionetprecision.resource;

import com.airton.desafionetprecision.dto.EmployeeDTO;
import com.airton.desafionetprecision.entities.Employee;
import com.airton.desafionetprecision.service.EmployeeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employee")
public class EmployeeResource {

    private EmployeeService service;

    @PostMapping
    public ResponseEntity<EmployeeDTO> save(EmployeeDTO employeeDTO){
        EmployeeDTO saveDTO = service.save(employeeDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(employeeDTO);
    }

}
