package com.airton.desafionetprecision.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tb_employee")
public  class Employee extends Pessoa {

    @Column(unique = true, name = "login")
    private String login;

    @Column(unique = true, name = "password")
    private String password;

}
