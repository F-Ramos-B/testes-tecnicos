package com.airton.desafionetprecision;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafioNetprecisionApplication {

    public static void main(String[] args) {
        SpringApplication.run(DesafioNetprecisionApplication.class, args);
    }

}
