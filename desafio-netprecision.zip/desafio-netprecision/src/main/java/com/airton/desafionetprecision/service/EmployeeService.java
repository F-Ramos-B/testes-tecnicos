package com.airton.desafionetprecision.service;

import com.airton.desafionetprecision.dto.EmployeeDTO;
import com.airton.desafionetprecision.entities.Employee;
import com.airton.desafionetprecision.mapper.EmployeeMapper;
import com.airton.desafionetprecision.repositories.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository repository;

    public EmployeeDTO save(EmployeeDTO employeeDTO){
        Employee emp = EmployeeMapper.INSTANCE.toEntity(employeeDTO);
        return EmployeeMapper.INSTANCE.toDTO(repository.save(emp));
    }

}
